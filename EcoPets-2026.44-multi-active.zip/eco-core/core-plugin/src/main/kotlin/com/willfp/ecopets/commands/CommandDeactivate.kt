package com.willfp.ecopets.commands

import com.willfp.eco.core.command.impl.Subcommand
import com.willfp.eco.util.StringUtils
import com.willfp.ecopets.pets.Pets
import com.willfp.ecopets.pets.activePet
import com.willfp.ecopets.pets.activePets
import com.willfp.ecopets.pets.deactivatePet
import com.willfp.ecopets.plugin
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import org.bukkit.util.StringUtil

object CommandDeactivate : Subcommand(
    plugin,
    "deactivate",
    "ecopets.command.deactivate",
    true
) {
    override fun onExecute(player: CommandSender, args: List<String>) {
        player as Player

        val active = player.activePets
        if (active.isEmpty()) {
            player.sendMessage(plugin.langYml.getMessage("no-pet-active"))
            return
        }

        // /ecopets deactivate <pet> turns off one pet. No argument turns off all of them.
        if (args.isNotEmpty()) {
            val pet = Pets.getByID(args[0])
            if (pet == null || pet !in active) {
                player.sendMessage(plugin.langYml.getMessage("invalid-pet"))
                return
            }
            player.deactivatePet(pet)
            if (pet !in player.activePets) {
                player.sendMessage(
                    plugin.langYml.getMessage("deactivated-pet", StringUtils.FormatOption.WITHOUT_PLACEHOLDERS)
                        .replace("%pet%", pet.name)
                )
            }
            return
        }

        player.activePet = null
        if (player.activePets.isEmpty()) {
            player.sendMessage(
                plugin.langYml.getMessage("deactivated-pet", StringUtils.FormatOption.WITHOUT_PLACEHOLDERS)
                    .replace("%pet%", active.joinToString("&f, ") { it.name })
            )
        }
    }

    override fun tabComplete(sender: CommandSender, args: List<String>): List<String> {
        if (sender !is Player || args.size != 1) {
            return emptyList()
        }
        val completions = mutableListOf<String>()
        StringUtil.copyPartialMatches(args[0], sender.activePets.map { it.id }, completions)
        return completions
    }
}
