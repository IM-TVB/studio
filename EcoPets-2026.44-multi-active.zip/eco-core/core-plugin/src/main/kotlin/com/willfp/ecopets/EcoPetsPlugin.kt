package com.willfp.ecopets

import com.willfp.eco.core.bstats.EcoMetricsChart
import com.willfp.eco.core.command.impl.PluginCommand
import com.willfp.eco.core.integrations.IntegrationLoader
import com.willfp.eco.core.items.Items
import com.willfp.eco.core.placeholder.PlayerPlaceholder
import com.willfp.eco.util.StringUtils
import com.willfp.eco.util.toNiceString
import com.willfp.eco.util.toNumeral
import com.willfp.ecopets.commands.CommandEcoPets
import com.willfp.ecopets.commands.CommandPets
import com.willfp.ecopets.items.ArgParserPetLevel
import com.willfp.ecopets.items.ArgParserPetXp
import com.willfp.ecopets.libreforge.ConditionHasActivePet
import com.willfp.ecopets.libreforge.ConditionHasPet
import com.willfp.ecopets.libreforge.ConditionHasPetLevel
import com.willfp.ecopets.libreforge.EffectActivatePet
import com.willfp.ecopets.libreforge.EffectDeactivatePet
import com.willfp.ecopets.libreforge.EffectGivePetXp
import com.willfp.ecopets.libreforge.EffectPetXpMultiplier
import com.willfp.ecopets.libreforge.FilterPet
import com.willfp.ecopets.libreforge.MutatorPlayerToPet
import com.willfp.ecopets.libreforge.MutatorPlayerToPetLocation
import com.willfp.ecopets.libreforge.TriggerGainPetXp
import com.willfp.ecopets.libreforge.TriggerLevelUpPet
import com.willfp.ecopets.libreforge.TriggerPetActivate
import com.willfp.ecopets.libreforge.TriggerPetDeactivate
import com.willfp.ecopets.pets.DiscoverRecipeListener
import com.willfp.ecopets.pets.PetDisplay
import com.willfp.ecopets.pets.PetLevelListener
import com.willfp.ecopets.pets.Pets
import com.willfp.ecopets.pets.PetsGUI
import com.willfp.ecopets.pets.SpawnEggHandler
import com.willfp.ecopets.pets.activePet
import com.willfp.ecopets.pets.activePets
import com.willfp.ecopets.pets.deactivatePet
import com.willfp.ecopets.pets.getPetLevelObject
import com.willfp.ecopets.pets.getPetLevel
import com.willfp.ecopets.pets.getPetProgress
import com.willfp.ecopets.pets.getPetXP
import com.willfp.ecopets.pets.entity.ModelPetEntity
import com.willfp.ecopets.pets.entity.PetEntity
import com.willfp.ecopets.pets.hasPet
import com.willfp.libreforge.SimpleProvidedHolder
import com.willfp.libreforge.conditions.Conditions
import com.willfp.libreforge.effects.Effects
import com.willfp.libreforge.filters.Filters
import com.willfp.libreforge.loader.LibreforgePlugin
import com.willfp.libreforge.loader.configs.ConfigCategory
import com.willfp.libreforge.mutators.Mutators
import com.willfp.libreforge.registerSpecificHolderProvider
import com.willfp.libreforge.triggers.Triggers
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.event.Listener

internal lateinit var plugin: EcoPetsPlugin
    private set

class EcoPetsPlugin : LibreforgePlugin() {
    private val petDisplay = PetDisplay

    init {
        plugin = this
    }

    override fun loadConfigCategories(): List<ConfigCategory> {
        return listOf(
            Pets
        )
    }

    override fun handleEnable() {
        Conditions.register(ConditionHasPetLevel)
        Conditions.register(ConditionHasActivePet)
        Conditions.register(ConditionHasPet)
        Effects.register(EffectPetXpMultiplier)
        Effects.register(EffectGivePetXp)
        Effects.register(EffectActivatePet)
        Effects.register(EffectDeactivatePet)
        Triggers.register(TriggerGainPetXp)
        Triggers.register(TriggerLevelUpPet)
        Triggers.register(TriggerPetActivate)
        Triggers.register(TriggerPetDeactivate)
        Filters.register(FilterPet)
        Mutators.register(MutatorPlayerToPet)
        Mutators.register(MutatorPlayerToPetLocation)

        Items.registerArgParser(ArgParserPetLevel)
        Items.registerArgParser(ArgParserPetXp)

        registerSpecificHolderProvider<Player> {
            if (isDisabledIn(it.world)) emptyList() else
                it.activePets.map { pet ->
                    SimpleProvidedHolder(it.getPetLevelObject(pet))
                }
        }

        PlayerPlaceholder(
            this,
            "pet"
        ) { it.activePet?.name ?: "" }.register()

        PlayerPlaceholder(
            this,
            "pet_id"
        ) { it.activePet?.id ?: "" }.register()

        PlayerPlaceholder(
            this,
            "total_pets"
        ) {
            var pets = 0
            for (pet in Pets.values()) {
                if (it.hasPet(pet))
                    pets++
            }
            pets.toString()
        }.register()
    }

    private fun registerActivePetPlaceholders() {
        PlayerPlaceholder(
            this,
            "active_pet_level"
        ) {
            it.activePet?.let { pet -> it.getPetLevel(pet).toString() }.orEmpty()
        }.register()

        PlayerPlaceholder(
            this,
            "active_pet_level_numeral"
        ) {
            it.activePet?.let { pet -> it.getPetLevel(pet).toNumeral() }.orEmpty()
        }.register()

        PlayerPlaceholder(
            this,
            "active_pet_current_xp"
        ) {
            it.activePet?.let { pet -> it.getPetXP(pet).toNiceString() }.orEmpty()
        }.register()

        PlayerPlaceholder(
            this,
            "active_pet_required_xp"
        ) {
            it.activePet?.let { pet -> pet.getFormattedExpForLevel(it.getPetLevel(pet) + 1) }.orEmpty()
        }.register()

        PlayerPlaceholder(
            this,
            "active_pet_percentage_progress"
        ) {
            it.activePet?.let { pet -> (it.getPetProgress(pet) * PERCENT).toNiceString() }.orEmpty()
        }.register()

        PlayerPlaceholder(
            this,
            "active_pet_description"
        ) {
            it.activePet?.description.orEmpty()
        }.register()
    }

    override fun handleReload() {
        registerActivePetPlaceholders()
        PetsGUI.update()
        petDisplay.reload()

        this.scheduler.global().runTimer(20, 20) {
            if (this.configYml.getBool("auto-deactivate-on-condition-fail")) {
                for (player in Bukkit.getOnlinePlayers()) {
                    player.runOwned { autoDeactivate(player) }
                }
            }
        }

        if (!this.configYml.getBool("pet-entity.enabled")) {
            return
        }

        this.scheduler.global().runTimer(1, 1) {
            petDisplay.tickAll()
        }
    }

    private fun autoDeactivate(player: Player) {
        if (!player.isOnline) {
            return
        }

        for (pet in player.activePets) {
            if (!pet.canActivate(player)) {
                player.deactivatePet(pet)
                if (pet !in player.activePets) {
                    player.sendMessage(
                        this.langYml.getMessage("pet-auto-deactivated", StringUtils.FormatOption.WITHOUT_PLACEHOLDERS)
                            .replace("%pet%", pet.name)
                    )
                }
            }
        }
    }

    override fun handleDisable() {
        petDisplay.shutdown()
    }

    override fun loadIntegrationLoaders(): List<IntegrationLoader> {
        return listOf(
            IntegrationLoader("ModelEngine") {
                PetEntity.registerPetEntity("modelengine") { pet, texture ->
                    ModelPetEntity(pet, "model-engine", texture)
                }
            },
            IntegrationLoader("BetterModel") {
                PetEntity.registerPetEntity("bettermodel") { pet, texture ->
                    ModelPetEntity(pet, "better-model", texture)
                }
            }
        )
    }

    override fun loadPluginCommands(): List<PluginCommand> {
        return listOf(
            CommandEcoPets,
            CommandPets
        )
    }

    override fun loadListeners(): List<Listener> {
        return listOf(
            PetLevelListener,
            SpawnEggHandler,
            petDisplay,
            DiscoverRecipeListener
        )
    }

    override fun getCustomCharts() = listOf(
        EcoMetricsChart.SingleLine("total_pets") { Pets.values().size },
        EcoMetricsChart.SimplePie("pet_entity_enabled") {
            if (configYml.getBool("pet-entity.enabled")) "enabled" else "disabled"
        },
        EcoMetricsChart.SimplePie("pet_hologram_enabled") {
            if (configYml.getBool("pet-entity.show-hologram")) "enabled" else "disabled"
        },
        EcoMetricsChart.SimplePie("auto_deactivate_on_fail") {
            if (configYml.getBool("auto-deactivate-on-condition-fail")) "enabled" else "disabled"
        },
        EcoMetricsChart.SimplePie("level_up_messages") {
            if (configYml.getBool("level-up.message.enabled")) "enabled" else "disabled"
        }
    )
}

private const val PERCENT = 100
