package com.willfp.ecopets.commands

import com.willfp.eco.core.command.impl.Subcommand
import com.willfp.eco.util.StringUtils
import com.willfp.ecopets.api.event.PlayerPetSwapEvent
import com.willfp.ecopets.pets.Pets
import com.willfp.ecopets.pets.activePet
import com.willfp.ecopets.pets.activePets
import com.willfp.ecopets.pets.activatePet
import com.willfp.ecopets.pets.maxActivePets
import com.willfp.ecopets.pets.hasPet
import com.willfp.ecopets.plugin
import org.bukkit.Bukkit
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import org.bukkit.util.StringUtil

object CommandActivate : Subcommand(
    plugin,
    "activate",
    "ecopets.command.activate",
    true
) {
    override fun onExecute(player: CommandSender, args: List<String>) {
        player as Player

        if (args.isEmpty()) {
            player.sendMessage(plugin.langYml.getMessage("needs-pet"))
            return
        }

        val id = args[0]

        val pet = Pets.getByID(id)

        if (pet == null || !player.hasPet(pet)) {
            player.sendMessage(plugin.langYml.getMessage("invalid-pet"))
            return
        }

        if (pet in player.activePets) {
            player.sendMessage(plugin.langYml.getMessage("pet-already-active"))
            return
        }

        if (!pet.canActivate(player)) {
            player.sendMessage(
                plugin.langYml.getMessage("cannot-activate-pet", StringUtils.FormatOption.WITHOUT_PLACEHOLDERS)
                    .replace("%pet%", pet.name)
            )
            return
        }

        if (player.activePets.size >= player.maxActivePets) {
            if (player.maxActivePets == 1) {
                // Only 1 slot: swap like the old behaviour.
                player.activePet?.let { oldPet ->
                    val event = PlayerPetSwapEvent(player, pet, oldPet)
                    Bukkit.getServer().pluginManager.callEvent(event)
                    if (event.isCancelled) {
                        player.sendMessage(plugin.langYml.getMessage("cancelled-swap"))
                        return
                    }
                }
                player.activePet = pet
            } else {
                player.sendMessage(
                    plugin.langYml.getMessage("max-active-pets-reached", StringUtils.FormatOption.WITHOUT_PLACEHOLDERS)
                        .replace("%max%", player.maxActivePets.toString())
                )
                return
            }
        } else {
            player.activatePet(pet)
        }

        if (pet in player.activePets) {
            player.sendMessage(
                plugin.langYml.getMessage("activated-pet", StringUtils.FormatOption.WITHOUT_PLACEHOLDERS)
                    .replace("%pet%", pet.name)
            )
        }
    }

    override fun tabComplete(sender: CommandSender, args: List<String>): List<String> {
        if (sender !is Player) {
            return emptyList()
        }

        val completions = mutableListOf<String>()
        if (args.size == 1) {
            StringUtil.copyPartialMatches(
                args[0],
                Pets.values().filter { sender.hasPet(it) }.map { it.id },
                completions
            )
            return completions
        }

        return emptyList()
    }
}
