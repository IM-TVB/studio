package com.willfp.ecopets.libreforge

import com.willfp.eco.core.config.interfaces.Config
import com.willfp.ecopets.pets.Pets
import com.willfp.ecopets.pets.givePetExperience
import com.willfp.libreforge.ArgType
import com.willfp.libreforge.NoCompileData
import com.willfp.libreforge.arguments
import com.willfp.libreforge.effects.Effect
import com.willfp.libreforge.getFormattedString
import com.willfp.libreforge.triggers.TriggerData
import com.willfp.libreforge.triggers.TriggerParameter

object EffectGivePetXp : Effect<NoCompileData>("give_pet_xp") {
    override val description = "Gives the player experience towards the specified pet. " +
        "Does nothing if the player has not adopted the pet."

    override val categories = setOf("player", "economy")

    override val parameters = setOf(
        TriggerParameter.PLAYER
    )

    override val arguments = arguments {
        require(
            "amount",
            "You must specify the amount of xp to give!",
            description = "The amount of pet experience to give.",
            type = ArgType.EXPRESSION,
            example = "%level% * 10"
        )
        require(
            "pet",
            "You must specify the pet to give xp for!",
            description = "The ID of the pet to give experience to.",
            type = ArgType.STRING
        )
    }

    override fun onTrigger(config: Config, data: TriggerData, compileData: NoCompileData): Boolean {
        val player = data.player ?: return false

        // givePetExperience already guards on the player having adopted the pet - do not add a
        // second check here.
        player.givePetExperience(
            Pets.getByID(config.getFormattedString("pet", data)) ?: return false,
            config.getDoubleFromExpression("amount", player)
        )

        return true
    }
}
